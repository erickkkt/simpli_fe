
export interface SearchResult {
    positions: number[];
}
