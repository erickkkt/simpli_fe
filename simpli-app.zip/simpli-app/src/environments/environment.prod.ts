export const environment = {
  production: true,
  apiUrl: 'https://simpli-search-portal-api.azurewebsites.net',
};